$("#phone").intlTelInput({
  defaultCountry: "auto",
  utilsScript: "../../lib/libphonenumber/build/utils.js" // just for formatting/placeholders etc
});